package com.exec;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.*;
import javax.swing.plaf.TextUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.JTextComponent;
import java.awt.event.*;

public class connection {

    public static void main(String[] args) {

        JFrame f = new JFrame("Loyalty Card");
        f.setSize(1000,400);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

        ImageIcon image = new ImageIcon("logo-speed-cash.png");

        JPanel pannel = new JPanel();

        GridBagLayout gb = new GridBagLayout();

        GridBagConstraints gbc = new GridBagConstraints();
        pannel.setLayout(gb);

        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 1;
        gbc.weightx = 1;
        gbc.weighty = 1;

        JLabel label = new JLabel();
        label.setText("Bienvenue sur votre compteur de point Speed Cash!");
        pannel.add(label);

        JTextField  idInputField = new JTextField ("username");
        pannel.add(idInputField);

        JPasswordField  passwordInputField = new JPasswordField ("password");
        pannel.add(passwordInputField);

        JButton bouton1 = new JButton("Connexion");
        bouton1.addActionListener(evt1 -> printUserResults(idInputField.getText(), String.valueOf(passwordInputField.getPassword()))
        );
        pannel.add(bouton1);


        JButton bouton2 = new JButton("Exit");
        bouton2.addActionListener(evt2 -> System.exit(0)
        );
        pannel.add(bouton2);

        gb.setConstraints(label, gbc);
        gb.setConstraints(idInputField, gbc);
        gb.setConstraints(passwordInputField, gbc);
        gb.setConstraints(bouton1, gbc);
        gb.setConstraints(bouton2, gbc);

        //pannel.pack();
        f.setIconImage(image.getImage());
        f.getContentPane().add(pannel);
        f.setLocation(dim.width/2 - f.getWidth()/2, dim.height/2 - f.getHeight()/2);
        f.setVisible(true);
    }

    public static void printUserResults( String IdInput, String PasswordInput) {

        JFrame frame1 = new JFrame("Database Search Result");
        frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame1.setLayout(new BorderLayout());
        JPanel pannel1 = new JPanel();

        String[] columnNames = {"Nom", "Points"};

        String nom = "";
        String points = "";

        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(columnNames);

        JTable table = new JTable();
        table.setModel(model);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.setFillsViewportHeight(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        if (!IdInput.isEmpty() && !PasswordInput.isEmpty()) {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con=DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/client","root","root");
                Statement stmt=con.createStatement();
                ResultSet rs=stmt.executeQuery("select * from client where user = '" + IdInput + "'" + "and password = '" + PasswordInput + "'");
                System.out.println("Connected");
                if(rs.next()) {
                    //System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
                    nom = rs.getString("user");
                    points = "Vous avez " + rs.getString("points") + " points";

                    model.addRow(new Object[]{nom, points});
                    //con.close();
                }else {
                    JOptionPane.showMessageDialog(null, "Wrong User or Password");
                }
            }
            catch(Exception ex)
            {
                System.err.println(ex);
                ex.printStackTrace();
            }
        }else{
            JOptionPane.showMessageDialog(null, "Please enter a user name");
        }

        JLabel label1 = new JLabel("10 points = 1€");
        label1.setText("10 points = 1€");
        frame1.add(label1);
        JLabel label2 = new JLabel("Vous pouvez convertir vos points sur : URL");
        label2.setText("Vous pouvez convertir vos points sur : URL");
        frame1.add(label2);

        frame1.getContentPane().add(pannel1);
        frame1.add(scroll);
        frame1.setVisible(true);
        frame1.setSize(400,300);
    }
}
